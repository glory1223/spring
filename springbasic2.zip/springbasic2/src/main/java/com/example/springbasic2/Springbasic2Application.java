package com.example.springbasic2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbasic2Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbasic2Application.class, args);
	}

}
