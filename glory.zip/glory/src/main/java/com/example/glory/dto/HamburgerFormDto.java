package com.example.glory.dto;

public class HamburgerFormDto {
}
