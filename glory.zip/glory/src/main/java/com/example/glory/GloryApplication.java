package com.example.glory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GloryApplication {

	public static void main(String[] args) {
		SpringApplication.run(GloryApplication.class, args);
	}

}
