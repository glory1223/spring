package com.example.glory.constant;

public enum Role {
    ADMIN, USER
}
