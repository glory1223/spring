package com.example.springbasic2.constant;

public enum OrderStatus {
    ORDER, CANCEL
}
