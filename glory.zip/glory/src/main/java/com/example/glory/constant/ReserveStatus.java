package com.example.glory.constant;

public enum ReserveStatus {
    RESERVE, CANCEL
}
