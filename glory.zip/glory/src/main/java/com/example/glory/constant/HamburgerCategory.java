package com.example.glory.constant;

public enum HamburgerCategory {
    RECOMMEND, BURGER_SET, DRINK, DESERT, SNACK
}
