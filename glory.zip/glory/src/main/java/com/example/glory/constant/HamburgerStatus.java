package com.example.glory.constant;

public enum HamburgerStatus {
    SELL, SOLD_OUT
}
